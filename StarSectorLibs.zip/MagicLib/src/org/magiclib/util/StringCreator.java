package org.magiclib.util;

/**
 * Do not use.
 */
public interface StringCreator {
    String create();
}
