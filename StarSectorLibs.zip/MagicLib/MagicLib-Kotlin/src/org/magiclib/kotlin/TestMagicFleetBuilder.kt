package org.magiclib.kotlin

import com.fs.starfarer.api.Global
//import org.magiclib.campaign.MagicFleetBuilder

internal object TestMagicFleetBuilder {
    fun testMagicFleetBuilder() {
//        val sector = Global.getSector()
//        val corvus = sector.getStarSystem("corvus")
//        sector.playerFleet.containingLocation = corvus
//
//        assert(MagicFleetBuilder().create() == null) { "Fleet with no location should fail to create." }
//
//        assert(
//            MagicFleetBuilder()
//                .setSpawnLocation(sector.playerFleet)
//                .create() != null
//        ) { "Spawn on player with setSpawnLocation." }
//
//        assert(
//            MagicFleetBuilder()
//                .setAssignmentTarget(sector.playerFleet)
//                .create() != null
//        ) { "Spawn on player with setAssignmentTarget." }

    }
}