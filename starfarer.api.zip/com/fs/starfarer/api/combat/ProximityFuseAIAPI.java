package com.fs.starfarer.api.combat;

public interface ProximityFuseAIAPI {
	void updateDamage();
}
