package com.fs.starfarer.api.combat;

public class AdmiralAIConfig {

	public AdmiralAIConfig() {
		
	}
	
	
}
