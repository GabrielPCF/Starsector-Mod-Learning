package com.fs.starfarer.api.impl.campaign.econ;



public class Decivilized extends BaseHazardCondition {
	
	public void apply(String id) {
		super.apply(id);
	}

	public void unapply(String id) {
		super.unapply(id);
	}

}
