package com.fs.starfarer.api.campaign;

public enum CoreUITabId {
	CHARACTER,
	FLEET,
	REFIT,
	CARGO,
	MAP,
	INTEL,
	//OFFICERS,
	OUTPOSTS,
}
