package com.fs.starfarer.api.characters;

public interface FleetTotalSource {
	FleetTotalItem getFleetTotalItem();
}
