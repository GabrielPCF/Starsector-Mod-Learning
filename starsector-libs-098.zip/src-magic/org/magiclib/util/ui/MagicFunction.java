package org.magiclib.util.ui;

public interface MagicFunction {
    void doFunction();
}
