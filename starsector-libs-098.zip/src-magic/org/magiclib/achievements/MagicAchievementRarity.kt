package org.magiclib.achievements

enum class MagicAchievementRarity {
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
}