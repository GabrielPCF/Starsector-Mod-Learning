package data.scripts.util;

@Deprecated
public interface StringCreator {
    String create();
}
