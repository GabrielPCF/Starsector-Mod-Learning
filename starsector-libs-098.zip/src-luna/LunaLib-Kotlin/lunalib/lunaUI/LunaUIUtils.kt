package lunalib.lunaUI

import java.util.WeakHashMap

object LunaUIUtils {
    var selectedElements: HashMap<String, String?> = HashMap()
}